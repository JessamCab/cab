function addRecommendation() {
    // Get the message of the new recommendation
    let recommendation = document.getElementById("new_recommendation");
    
    // Check if the user has actually entered a message
    if (recommendation.value != null && recommendation.value.trim() != "") {
      console.log("New recommendation added");
      
      // --- REQUIREMENT: Call showPopup(true) to show the success message ---
      showPopup(true);
  
      // Create a new recommendation element
      var element = document.createElement("div");
      element.setAttribute("class", "recommendation");
      
      // Set the innerHTML with quotation marks and the user's text
      element.innerHTML = "<span>&#8220;</span>" + recommendation.value + "<span>&#8221;</span>";
      
      // Add the new recommendation to the list
      document.getElementById("all_recommendations").appendChild(element); 
      
      // Clear the textarea for the next entry
      recommendation.value = "";
    }
  }
  
  /**
   * Shows or hides the success popup
   * @param {boolean} bool - true to show, false to hide
   */
  function showPopup(bool) {
    if (bool) {
      document.getElementById('popup').style.visibility = 'visible';
    } else {
      document.getElementById('popup').style.visibility = 'hidden';
    }
  }